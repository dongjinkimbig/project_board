create definer = root@localhost view vw_member_left_profile as
select `aidev`.`tb_member`.`mem_userid` AS `mem_userid`,
       `aidev`.`tb_member`.`mem_name`   AS `mem_name`,
       `aidev`.`tb_member`.`mem_hp`     AS `mem_hp`,
       `aidev`.`tb_profile`.`pro_age`   AS `pro_age`,
       `aidev`.`tb_profile`.`pro_blood` AS `pro_blood`,
       `aidev`.`tb_profile`.`pro_mbti`  AS `pro_mbti`
from (`aidev`.`tb_member` left join `aidev`.`tb_profile`
      on ((`aidev`.`tb_member`.`mem_idx` = `aidev`.`tb_profile`.`pro_idx`)));

